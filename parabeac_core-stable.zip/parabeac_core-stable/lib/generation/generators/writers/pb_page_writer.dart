abstract class PBPageWriter {
  void write(String code, String fileName);

  void append(String code, String fileName);
}
