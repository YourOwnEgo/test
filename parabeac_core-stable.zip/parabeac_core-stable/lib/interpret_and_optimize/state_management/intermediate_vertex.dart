class IntermediateVertex {}
