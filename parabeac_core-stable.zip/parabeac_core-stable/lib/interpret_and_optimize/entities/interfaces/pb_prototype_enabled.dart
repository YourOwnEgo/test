import 'package:parabeac_core/generation/prototyping/pb_prototype_node.dart';

//TODO: refactoring it into [PBIntermediateNode]
abstract class PrototypeEnable {
  PrototypeNode prototypeNode;
}
