class PBSymbolInstanceOverridableValue {
  final Type type;

  final String UUID;
  final dynamic value;

  PBSymbolInstanceOverridableValue(this.UUID, this.value, this.type);
}
