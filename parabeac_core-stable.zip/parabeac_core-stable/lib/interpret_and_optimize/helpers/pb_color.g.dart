// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pb_color.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PBColor _$PBColorFromJson(Map<String, dynamic> json) {
  return PBColor(
    json['a'] as num,
    json['r'] as num,
    json['g'] as num,
    json['b'] as num,
  );
}

Map<String, dynamic> _$PBColorToJson(PBColor instance) => <String, dynamic>{
      'a': instance.a,
      'r': instance.r,
      'g': instance.g,
      'b': instance.b,
    };
